<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Email
    |--------------------------------------------------------------------------
    |
    |
    */
    
    'app_name' => "Anonymous PHP Script",
    'good_day' => "Good Day",
    'all_rights_reserved' => "All rights reserved.",
    
];
