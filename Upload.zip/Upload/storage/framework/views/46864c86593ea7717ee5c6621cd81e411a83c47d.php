
<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?>

            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin/genders')); ?>">
                        <?php echo e(__('Genders')); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
    </div>
</div>

<div class="row row-cards">
    
    <div class="col-12">
        <div class="card">
            <form method="post" action="<?php echo e(route('store_new_gender')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Name')); ?></label>
                        <div class="col">
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>" name="name" placeholder="<?php echo e(__('Name...')); ?>">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Description')); ?></label>
                        <div class="col">
                            <input type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('description')); ?>" name="description" placeholder="<?php echo e(__('Short description...')); ?>">

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="form-group mb-3 row">
                        <label class="form-label col-3 col-form-label"><?php echo e(__('Color')); ?></label>
                        <div class="col">
                            
                            <div class="row g-2">
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-dark" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-dark rounded-circle"></span>
                                    </label>
                                </div>
                                
                                <div class="col-auto">
                                    <label class="form-colorinput form-colorinput-light">
                                        <input name="bg_color" type="radio" value="bg-white" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-white rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-blue" class="form-colorinput-input" name="bg_color">
                                        <span class="form-colorinput-color bg-blue rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-azure" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-azure rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-indigo" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-indigo rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-purple" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-purple rounded-circle"></span>
                                    </label>
                                </div>
                                
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-pink" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-pink rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-red" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-red rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-orange" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-orange rounded-circle"></span>
                                    </label>
                                </div>

                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-yellow" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-yellow rounded-circle"></span>
                                    </label>
                                </div>
                            
                                <div class="col-auto">
                                    <label class="form-colorinput">
                                        <input name="bg_color" type="radio" value="bg-lime" class="form-colorinput-input">
                                        <span class="form-colorinput-color bg-lime rounded-circle"></span>
                                    </label>
                                </div>
                            </div>

                            <?php $__errorArgs = ['bg_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Create')); ?></button>
                </div>
            </form>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views\admin\genders\create_gender.blade.php ENDPATH**/ ?>