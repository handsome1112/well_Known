<div class="card mb-3">
    <div class="card-header">
        <h2 class="card-title">
            <?php echo e(__('main.w_top_users')); ?>

        </h2>
    </div>
    <table class="table card-table">
        <thead>
            <tr>
                <th><?php echo e(__('main.w_user')); ?></th>
                <th class="w-5"><?php echo e(__('main.w_score')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $topUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('profile', $user->name)); ?>" class="text-decoration-none strong">
                        <span class="avatar avatar-xs avatar-rounded" <?php if(!empty($user->avatar)): ?> style="background-image: url(<?php echo e(asset('storage/app/public/images/avatar/'.$user->avatar)); ?>)" <?php endif; ?>>
                        <?php if(empty($user->avatar)): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="7" r="4" /><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" /></svg>
                            <?php endif; ?>

                            <?php if(Cache::has('user-is-online-' . $user->id)): ?>
                            <span class="badge bg-green" title="<?php echo e(__('main.card_online')); ?>"></span>
                            <?php else: ?>
                            <span class="badge bg-x" title="<?php echo e(__('main.card_offline')); ?>"></span>
                            <?php endif; ?>
                        </span>
                        <span class="text-truncate"><?php echo e($user->name); ?></span>
                    </a>
                </td>
                <td>
                    <span class="badge badge-pill bg-red-lt">
                        <?php echo e($user->total_point_count()); ?>

                    </span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="empty">
                <div class="empty-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="12" cy="12" r="9"></circle><line x1="9" y1="10" x2="9.01" y2="10"></line><line x1="15" y1="10" x2="15.01" y2="10"></line><path d="M9.5 15.25a3.5 3.5 0 0 1 5 0"></path></svg>
                </div>
                <p class="empty-title">
                    <?php echo e(__('main.w_no_rated_users')); ?>

                </p>
            </div>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/layouts/topUsers.blade.php ENDPATH**/ ?>