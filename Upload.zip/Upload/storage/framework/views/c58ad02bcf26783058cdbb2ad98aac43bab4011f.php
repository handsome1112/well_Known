
<?php $__env->startSection('content'); ?>
<div class="page-header text-white d-print-none">
    <div class="row align-items-center">
        <div class="col-auto">
            <span class="avatar avatar-rounded bg-blue-lt">
                <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M9 4h3l2 2h5a2 2 0 0 1 2 2v7a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2" /><path d="M17 17v2a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2h2" /></svg>
            </span>
        </div>
        <div class="col">
            <h2 class="page-title">
                <?php echo e($getCategory->name); ?>    
            </h2>
        </div>
    </div>
</div>
<!-- latest Items Section -->
<div class="row" data-masonry='{"percentPosition": true }'>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if(!empty($setting_adv_top)): ?>
    <?php if($adv_top->status == 1): ?>
    <?php if($loop->first): ?>
    <div class="col-3">
        <div class="card">
            <div class="card-body text-center">
                <p><?php echo $adv_top->value; ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(!empty($setting_adv_bottom)): ?>
    <?php if($adv_bottom->status == 1): ?>
    <?php if($loop->last): ?>
    <div class="col-3">
        <div class="card">
            <div class="card-body text-center">
                <p><?php echo $adv_bottom->value; ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php echo $__env->make('layouts.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
</div>

<div class="row">
    <div class="col-lg-12">
        <!-- if you don't have enough points to view -->
        <?php if($userPoints < $getCategory->score): ?>
        <?php echo $__env->make('layouts.getMorePoints', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- if the list is empty -->
        <?php elseif($items->isEmpty()): ?>
        <?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end if the list is empty -->
        <?php endif; ?>
    </div>
</div>


<div class="row">
    <div class="col-lg-12">
        <?php echo e($items->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/layouts/categories/index.blade.php ENDPATH**/ ?>