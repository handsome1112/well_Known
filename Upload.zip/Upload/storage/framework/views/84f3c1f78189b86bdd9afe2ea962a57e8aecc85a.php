<div class="row">
    <div class="empty">
        <div class="empty-img">
            <img src="<?php echo e(asset('resources/views/assets/img/block.svg')); ?>" alt="">
        </div>
        <div class="empty-header">
            <?php echo e(__('points.access_is_not_allowed')); ?>

        </div>
        <p class="empty-title">
            <?php echo e(__('points.points_needed_to_enter', ['score'=>$getCategory->score])); ?>

        </p>
    </div>
</div><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/layouts/getMorePoints.blade.php ENDPATH**/ ?>