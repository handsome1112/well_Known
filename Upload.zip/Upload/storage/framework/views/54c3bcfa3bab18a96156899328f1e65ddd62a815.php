<?php echo e($slot); ?>

<?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>