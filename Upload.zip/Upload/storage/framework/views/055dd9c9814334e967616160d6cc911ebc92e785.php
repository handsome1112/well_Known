
<?php $__env->startSection('content'); ?>

<div class="page-header">
    <div class="row align-items-center">
        <div class="col">
            <h1 class="page-title text-white">
                <?php echo e($getCategory->name); ?>

            </h1>
        </div>
    </div>
</div>

<!-- latest Items Section -->
<div class="row" data-masonry='{"percentPosition": true }'>

    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php if(!empty($setting_adv_top)): ?>
    <?php if($adv_top->status == 1): ?>
    <?php if($loop->first): ?>
    <div class="col-3">
        <div class="card">
            <div class="card-body text-center">
                <p><?php echo $adv_top->value; ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(!empty($setting_adv_bottom)): ?>
    <?php if($adv_bottom->status == 1): ?>
    <?php if($loop->last): ?>
    <div class="col-3">
        <div class="card">
            <div class="card-body text-center">
                <p><?php echo $adv_bottom->value; ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>

    <?php echo $__env->make('layouts.item', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($items->isEmpty()): ?>
    <?php echo $__env->make('layouts.blank', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
        
</div>

<div class="row">
    <div class="col-lg-12">
        <?php echo e($items->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views\layouts\categories\index.blade.php ENDPATH**/ ?>