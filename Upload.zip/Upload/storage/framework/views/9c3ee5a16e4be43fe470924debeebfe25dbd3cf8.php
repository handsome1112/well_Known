
<?php $__env->startSection('content'); ?>

<div class="page-header d-print-none">
    <div class="row align-items-center">
        <div class="col">
            <h2 class="page-title">
                <?php echo e($page_name); ?>

            </h2>
            
            <ol class="breadcrumb breadcrumb-alternate" aria-label="breadcrumbs">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(url('admin')); ?>">
                        <?php echo e($site_name); ?>

                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="#">
                        <?php echo e($page_name); ?>

                    </a>
                </li>
            </ol>
            
        </div>
    </div>
</div>

<div class="row row-cards row-deck">
    
    <div class="table-responsive">
        <table class="table table-vcenter table-nowrap">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Gender</th>
                    <th>Points</th>
                    <th>Roles</th>
                    <th>Registered</th>
                    <th class="w-2">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td class="text-muted">
                        <span class="avatar avatar-xs avatar-rounded" <?php if(!empty($user->avatar)): ?> style="background-image: url(<?php echo e(asset('storage/app/public/images/avatar/'.$user->avatar)); ?>)" <?php endif; ?>>
                        <?php if(empty($user->avatar)): ?>
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="12" cy="7" r="4" /><path d="M6 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" /></svg>
                            <?php endif; ?>

                            <?php if(Cache::has('user-is-online-' . $user->id)): ?>
                            <span class="badge bg-green" title="<?php echo e(__('main.card_online')); ?>"></span>
                            <?php else: ?>
                            <span class="badge bg-x" title="<?php echo e(__('main.card_offline')); ?>"></span>
                            <?php endif; ?>
                        </span>
                        <?php echo e($user->name); ?>

                    </td>
                    <td class="text-muted"><?php echo e($user->email); ?></td>
                    <td class="text-muted">
                        <span class="badge <?php if(!empty($user->gender->bg_color)): ?><?php echo e($user->gender->bg_color); ?><?php endif; ?>">
                            <?php if(!empty($user->gender->name)): ?><?php echo e($user->gender->name); ?><?php else: ?><?php echo e(__('Not set')); ?><?php endif; ?>
                        </span>
                    </td>
                    
                    <td>
                        <span class="badge badge-pill bg-red-lt">
                            <?php echo e($user->total_point_count()); ?>

                        </span>
                    </td>
                    
                    <td>
                        <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="badge bg-secondary-lt">
                            <?php echo e($role->name); ?>

                        </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td class="text-reset"><?php echo e($user->created_at); ?></td>
                    <td>
                        
                        <a href="<?php echo e(route('edit_user', $user->id)); ?>" class="btn btn-sm">
                            <?php echo e(__('Edit')); ?>

                        </a>
                        <a href="<?php echo e(route('delete_user', $user->id)); ?>" onclick="return confirm('Do you confirm this operation?');" class="btn btn-sm btn-icon btn-link">
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon text-red" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="4" y1="7" x2="20" y2="7" /><line x1="10" y1="11" x2="10" y2="17" /><line x1="14" y1="11" x2="14" y2="17" /><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" /><path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" /></svg>
                        </a>
                        
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php echo e(__('There are no users.')); ?>

                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php echo e($users->links()); ?>

    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/admin/users/index.blade.php ENDPATH**/ ?>