<?php echo e($slot); ?>

<?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>