<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Marco\Desktop\xampp\htdocs\anonymous\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>